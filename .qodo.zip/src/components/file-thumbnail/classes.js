// ----------------------------------------------------------------------

export const fileThumbnailClasses = {
  root: 'mnl__file__thumbnail__root',
  img: 'mnl__file__thumbnail__img',
  icon: 'mnl__file__thumbnail__icon',
  removeBtn: 'mnl__file__thumbnail__remove__button',
  downloadBtn: 'mnl__file__thumbnail__download__button',
};
