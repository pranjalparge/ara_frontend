// ----------------------------------------------------------------------

export const svgColorClasses = { root: 'mnl__svg__color__root' };
